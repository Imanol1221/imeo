from module.service import Account
from module.utils.file import getList
from colorama import init, Fore
from time import sleep

import threading

init()

class Main():
    def __init__(self):
        print(Fore.LIGHTCYAN_EX + """


        ▀▀█▀▀ ░█──░█ ▀█▀ ▀▀█▀▀ ░█▀▀█ ░█─░█ 　 ░█▀▀█ ░█▀▀█ ── ░█▀▀█ ─█▀▀█ ▀▀█▀▀ ░█▀▀▀ 
        ─░█── ░█░█░█ ░█─ ─░█── ░█─── ░█▀▀█ 　 ░█─── ░█─── ▀▀ ░█─▄▄ ░█▄▄█ ─░█── ░█▀▀▀ 
        ─░█── ░█▄▀▄█ ▄█▄ ─░█── ░█▄▄█ ░█─░█ 　 ░█▄▄█ ░█▄▄█ ── ░█▄▄█ ░█─░█ ─░█── ░█▄▄▄
            """)

        print("")
        print(" Telegram: https://t.me/usernameloll | Discord: andresq.java")
        print("")
        try:
            self.num_ccs = int(input(Fore.LIGHTGREEN_EX + "- Cantidad de tarjetas: "))
            self.queue = int(input(Fore.LIGHTGREEN_EX + "- Longitud de la queue: "))

            print(Fore.LIGHTGREEN_EX + """

  1 - Taiwan
  2 - Reino Unido 

                """)

            self.fc = int(input(Fore.LIGHTGREEN_EX + "- Seleccionar: "))

            if self.fc == 1:
                self.fc = "TW"
            elif self.fc == 2:
                self.fc = "GB"

            print(Fore.LIGHTGREEN_EX + "- Checking...")

            self.semaphore = threading.Semaphore(self.queue)
            self.threads = []

            for i in range(self.num_ccs):
                t = threading.Thread(target=self.create_tasks, args=(getList("cards.txt")[i], self.fc,))
                t.start()
                self.threads.append(t)
                sleep(3)

            for t in self.threads:
                t.join()
        except Exception as e:
            print(Fore.LIGHTRED_EX + "- Error, Vuelve a comprobar la informacion.")
            input("")

    def create_tasks(self, cc, fc):
        self.semaphore.acquire()
        try:
            Account(cc, fc)
        except Exception as e:
            print(e)
            self.semaphore.release()
        finally:
            self.semaphore.release()

if __name__ == '__main__':
    Main()
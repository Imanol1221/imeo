from module.services.mail import Mail
from module.utils.file import save
from time import sleep

import random

class Create():
    def __init__(self, p, page, context, debug, user, password, cc, fc):
        self.cc = cc
        self.fc = fc

        self.p = p
        self.page = page
        self.context = context

        self.debug = debug

        self.user = user
        self.password = password

        self.register()

    def delay(self, sec):
        sleep(sec)

    def register(self):
        button = self.page.wait_for_selector('.ScCoreButton-sc-ocjdkq-0.ScCoreButtonPrimary-sc-ocjdkq-1.bTXTVH.gmCwLG')
        button.click() 

        self.delay(random.randint(1, 2))

        usr = self.page.wait_for_selector('#signup-username')
        pswd = self.page.wait_for_selector('#password-input')

        usr.fill(self.user)
        pswd.fill(self.password)

        another_form = False

        try:
            pswd_confirm = self.page.wait_for_selector('#password-input-confirmation', timeout=2000)
            pswd_confirm.fill(self.password)
            another_form = True
        except Exception:
            another_form = False
            pass

        self.delay(random.randint(1, 2))

        if another_form == False:
            button = self.page.wait_for_selector('[data-a-target="segmented-signup-next-button"]')
            button.click()

        button = self.page.wait_for_selector('[data-a-target="signup-phone-email-toggle"]')
        button.click()

        mail = Mail()
        try:
            mail.start()
        except:
            self.delay(2)
            mail = Mail()
            mail.start()

        email_addrs = mail.getEmail()

        email = self.page.wait_for_selector('#email-input')
        email.fill(email_addrs)

        self.delay(random.randint(1, 2))
        if another_form == False:
            button = self.page.wait_for_selector('[data-a-target="segmented-signup-next-button"]')
            button.click()
            self.delay(random.randint(1, 2))

        birthday_month = self.page.wait_for_selector('.ScInputBase-sc-vu7u7d-0.ScSelect-sc-gz38t2-0.gWqzmh.kxvSxQ.InjectLayout-sc-1i43xsx-0.ddpibn.tw-select')
        birthday_month.select_option(value="1")

        birthday_day = self.page.wait_for_selector('input[aria-label="Enter the day of your birth"]')
        birthday_day.fill("5")

        birthday_year = self.page.wait_for_selector('input[aria-label="Enter the year of your birth"]')
        birthday_year.fill("2000")

        button = self.page.wait_for_selector('[data-a-target="passport-signup-button"]')
        button.click()
        
        try:
            self.delay(random.randint(12, 18))
            mail.update()
            self.delay(2)
            mail.update()
            self.delay(2)
            mail.update()
        except:
            from module.service import Account

            self.page.close()
            self.context.close()
            self.p.stop()
            mail.stop()

            Account(self.cc, self.fc)

            return

        code = mail.getCode()

        if code.__eq__("no me mires que me sonrojo"):
            if self.debug:
                print("Invalid verify code. Retry...")
            from module.service import Account

            self.page.close()
            self.context.close()
            self.p.stop()
            mail.stop()

            Account(self.cc, self.fc)

            return

        if self.debug: 
            print(code + " - Validation code.")

        for i in range(1, 7):
            selector = f'[aria-label="Digit {i}"]'
            verify = self.page.wait_for_selector(selector)
            verify.fill(code[i-1])

        self.delay(3.2)

        mail.stop()

        if self.debug:
            save(f"""-------------------

    - Created!

      - Twitch (Login)
    - User: {self.user}
    - Pass: {self.password}
    {mail.getDetails()}
    -------------------
            """, "accounts.txt")
            print(f"Live account generated & saved! ({email_addrs})")

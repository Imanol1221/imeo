from time import sleep
from colorama import init, Fore
from module.utils.file import save

import random

init()

class Gate():
    def __init__(self, p, page, context, user, password, cc, fc):
        self.cc = cc
        self.fc = fc

        self.p = p
        self.context = context
        self.page = page
        
        self.user = user
        self.password = password

        self.register()

    def delay(self, sec):
        sleep(sec)

    def setISelector(self, title, value):
        frame_element = self.page.query_selector("iframe[title='" + title +"']")
        frame = frame_element.content_frame()

        select_elements = frame.query_selector_all("select")

        for select in select_elements:
            select.select_option(value)

    def setIInput(self, title, placeholder, value):
        frame_element = self.page.query_selector("iframe[title='" + title +"']")
        frame = frame_element.content_frame()

        element = frame.wait_for_selector('input[placeholder="' + placeholder + '"]')
        element.fill(value)

    def register(self):
        self.delay(2)

        button = self.page.wait_for_selector('[data-test-selector="onboarding-modal-splash-screen__button"]')
        button.click()

        button = self.page.wait_for_selector('[data-a-target="modalClose"]')
        button.click()

        button = self.page.wait_for_selector('[data-a-target="top-nav-get-bits-button"]', timeout=2000)
        button.click()

        self.delay(2)

        button = self.page.wait_for_selector('[data-a-target="bits-purchase-button-500"]')
        button.click()

        self.delay(2)

        name = self.page.wait_for_selector('input[placeholder="First Name"]')
        name.fill("Melard")

        lastname = self.page.wait_for_selector('input[placeholder="Last Name"]')
        lastname.fill("Westner")

        self.page.select_option('select[autocomplete="country"]', self.fc)

        self.delay(2)

        card = self.cc.split("|")

        self.setISelector("Month", card[1])
        self.setISelector("Year", "20" + card[2])

        self.setIInput("Card Number", "Card Number", card[0])
        self.setIInput("CVV", "CVV", card[3])

        button = self.page.wait_for_selector('[data-a-target="continue-button"]')
        button.click()

        self.delay(20)

        error = self.page.query_selector('input[placeholder="First Name"]')
        if error is None:
            print(Fore.LIGHTGREEN_EX + "[+] " + self.cc.replace("\n", "") + " (" + card[0][:-4] + ")")
            save("[+] " + self.cc.replace("\n", "") + " (" + card[0][:-4] + ")", "lives.txt")
        else:
            print(Fore.LIGHTRED_EX + "[-] " + self.cc.replace("\n", "") + " (" + card[0][:-4] + ")")
            save("[-] " + self.cc.replace("\n", "") + " (" + card[0][:-4] + ")", "deaths.txt")

        self.page.close()
        self.context.close()
        self.p.stop()
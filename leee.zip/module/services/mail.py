from mailtm import Email
from time import sleep

import string
import random

class Mail:
    def __init__(self):
        self.username = ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(24))
        self.password = ''.join(random.choice(string.ascii_letters + string.digits + string.punctuation) for _ in range(8))
        self.service = Email()
        self.email = ""
        self.code = "no me mires que me sonrojo"

    def listener(self, message):
        self.code = message['subject'].replace(" – Your Twitch Verification Code", "")

    def getCode(self):
        return self.code

    def getEmail(self):
        return self.email

    def getDetails(self):
        return f"""

    	  - Mail.tm (Login)
    	Email: {self.email}
    	Username: {self.username}
    	Password: {self.password}

    	"""

    def update(self):
    	self.service.torun()

    def start(self):
        self.service.register(self.username, self.password)
        self.service.start(self.listener)
        self.email = str(self.service.address)

    def stop(self):
        self.service.stop()
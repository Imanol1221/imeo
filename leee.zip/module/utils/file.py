def save(content, file):
    with open(file, "a") as f:
         f.write(content)

def getList(file):
    lines = []
    with open(file, "r") as f:
        for i in f:
            lines.append(i)
    return lines
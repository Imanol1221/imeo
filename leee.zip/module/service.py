from undetected_playwright.sync_api import sync_playwright
from module.services.create import Create
from module.services.gate import Gate
from screeninfo import get_monitors
from colorama import init, Fore
from random import randint, choice
from time import sleep


import string

init()

class Account():
    def __init__(self, cc, fc):
        self.cc = cc
        self.fc = fc

        self.args = []
        self.screen_width, self.screen_height = self.get_screen_resolution()

        self.dir = '/acc/' + str(randint(1, 20000)) + '/auto/playwright'
        self.chars = string.ascii_letters + string.digits

        self.args.append("--disable-blink-features=AutomationControlled")
        self.args.append("--enable-gpu")
        self.args.append("--enable-unsafe-webgpu")
        self.args.append("--disable-vulkan-fallback-to-gl-for-testingu")
        self.args.append("--dignore-gpu-blocklist")
        self.args.append("--use-angle=vulkan")

        self.p = sync_playwright().start()
        self.context = self.p.firefox.launch_persistent_context(
            self.dir,
            locale='en-US',
            geolocation={ 'longitude': 12.492507, 'latitude': 41.889938 },
            args=self.args,
            headless=False,
        )

        self.page = self.context.new_page()
        self.page.set_default_timeout(timeout=10000000)
        self.page.set_viewport_size({"width": self.screen_width, "height": self.screen_height})

        self.user = ''.join(choice(self.chars) for _ in range(12))
        self.password = ''.join(choice(self.chars) for _ in range(12))

        self.new_session()

        Create(self.p, self.page, self.context, False, self.user, self.password, self.cc, self.fc)
        print(Fore.LIGHTGREEN_EX + "- New account created.")

        Gate(self.p, self.page, self.context, self.user, self.password, self.cc, self.fc)

    def get_screen_resolution(self):
        monitor = get_monitors()[0]
        return monitor.width, monitor.height

    def new_session(self):
        sleep(2)
        self.page.goto('https://abrahamjuliot.github.io/creepjs/')
        sleep(2)
    